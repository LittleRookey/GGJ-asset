﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum playerFace
{
    North, South, West, East
};

public class PlayerController : MonoBehaviour {

    private Rigidbody2D rb;
    public float speed;

    public playerFace state;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        state = playerFace.North;

    }

    void Update()
    {
        Move();

    }

    public void Move()
    {
        if (Input.GetKey(KeyCode.W))
        {
            rb.AddForce(Vector2.up * speed);
            state = playerFace.North;

        }

        if (Input.GetKey(KeyCode.A))
        {
            rb.AddForce(-Vector2.right * speed);
            state = playerFace.West;

        }

        if (Input.GetKey(KeyCode.S))
        {
            rb.AddForce(-Vector2.up * speed);
            state = playerFace.South;
        }

        if (Input.GetKey(KeyCode.D))
        {
            rb.AddForce(Vector2.right * speed);
            state = playerFace.East;
        }
    }

    public class abc: PlayerController
    {
        
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Item"))
        {
            // item interact
            collision.gameObject.Interact();
        }
        else if (collision.gameObject.CompareTag("NPC"))
        {
            // NPC interact
            collision.gameObject.Interact();
        }
        else
        {
            return;
        }
    }

}
