﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthBar : MonoBehaviour {

    public Image currentHp;
    public Image hpEffect;
    
    private PlayerControl player;
    [SerializeField] private float hurtSpeed = 0.003f;

    void Awake() {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerControl>();
    }

    private void Update()
    {
        currentHp.fillAmount = player.currentHp / player.maxHp;

        if(hpEffect.fillAmount >= currentHp.fillAmount) {
            hpEffect.fillAmount -= hurtSpeed;
        } else {
            hpEffect.fillAmount = currentHp.fillAmount;
        }
    }

}
