﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour {

    private int maxSize = 24;

    [Header("All Slots you have (FIXED number)")]
    [SerializeField]
    private GameObject[] slots;

    [Header("One Dynamaic List which contains You space contains")]
    [SerializeField]
    private List<GameObject> items = new List<GameObject>();

    [SerializeField]
    private List<GameObject> itemPrefabs = new List<GameObject>();

    [Header("Pick up Test")]
    public GameObject Test19;

    private bool overload = false;

    private int randomNum;

    private void Awake()
    {
        //for (int i = 0; i < itemPrefabs.Count; i++)
        //{
        //    items.Add(itemPrefabs[i]);
        //}

        ShowCurrentItem();
    }

    private void Update()
    {
        //if (Input.GetKeyDown(KeyCode.E))
        //{
        //    Pickup();
        //}
    }

    //public void Pickup(GameObject pickUpItem) {//todo add parameter first
    public void Pickup()//todo transfer to the item.cs
    {
        if (!overload)
        {
            //TODO animation pick up
            // If character gets close to the object, pick up icon appears 
            // when item is picked up, adds the space to the item list and update the inventory
            items.Add(Test19);
            ShowCurrentItem();

            if (items.Count == slots.Length)
            {
                Debug.Log("Max Space of Your Bag");
                overload = true;
            }
        }
    }

    public void Throw() {
        randomNum = Random.Range(0, items.Count);
        items.Remove(items[randomNum]);

        slots[randomNum].transform.Find("Image").GetComponent<Image>().color = new Vector4(255, 255, 255, 0);
        slots[randomNum].transform.Find("Image").GetComponent<Image>().sprite = null;

        if (items.Count == 0) {
            Debug.Log("Min");
        }
    }

    private void ShowCurrentItem()
    {
        for (int i = 0; i < items.Count; i++)
        {
            //slots[i].transform.Find("Image").GetComponent<Image>().color = new Vector4(255, 255, 255, 255);
            //slots[i].transform.Find("Image").GetComponent<Image>().sprite = items[i].GetComponent<SpriteRenderer>().sprite;
        }
    }



}
