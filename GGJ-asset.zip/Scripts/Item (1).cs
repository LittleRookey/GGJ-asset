﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour {

    private ItemManager itemManager;

    [Header("Item Number Developer have to input first")]
    public int itemId;
    public GameObject showInfoWindow;

    public GetInfoSystem infoSystem;

    private void Awake()
    {
        itemManager = GameObject.Find("ItemManager").GetComponent<ItemManager>();
        infoSystem = GetComponent<GetInfoSystem>();
    }

    private void OnTriggerStay2D(Collider2D collision)//COMMENT player pick up the item
    {
        if (collision.CompareTag("Player")) 
        {
            showInfoWindow.GetComponent<ShowInfo>().WindowSystem(ShowName(), true);
            if (Input.GetKeyDown(KeyCode.Space))
            {
                showInfoWindow.GetComponent<ShowInfo>().WindowSystem("", false);

                StartCoroutine(DisappearDeath());
                StartCoroutine(infoSystem.InfoSystem());
                //Destroy(gameObject, 1.2f);

                infoSystem.itemNameText.text = ShowName();

                FindObjectOfType<Inventory>().Pickup();
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            showInfoWindow.GetComponent<ShowInfo>().WindowSystem("", false);
        }
    }

    string ShowName() {
        return itemManager.objects[itemId].itemName;
    }

    IEnumerator DisappearDeath() {
        gameObject.GetComponent<SpriteRenderer>().color = new Color32(255, 255, 255, 0);
        gameObject.GetComponent<PolygonCollider2D>().isTrigger = false;
        yield return new WaitForSeconds(1.5f);
        Destroy(gameObject);
    }


}
