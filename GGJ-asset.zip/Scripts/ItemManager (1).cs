﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoBehaviour {

    [System.Serializable]
    public class Item
    {

        public string itemName;
        public int itemId;
        public Sprite itemSprite;
        public int itemPrice;

        [TextArea]
        public string itemDescription;
        
        [Range(0, 1)] public float itemProbability;

    }

    [Header("Items' Basic Information Input Here")]
    public Item[] objects;

    [Header("All GameObject Prefabs Drag in Here")]
    public GameObject[] items;

}
