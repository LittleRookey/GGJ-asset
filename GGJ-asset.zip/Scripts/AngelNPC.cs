﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AngelNPC : MonoBehaviour
{

    public string inputText;

    public Text displayText;

    private int i = -1;
    private bool done;
    private string outputString;
    private int j = -1;
    private string[] angelSays;

    private void Start()
    {
        angelSays = new string[2];
        angelSays[0] = "You lived a good, moral life." +
            " I want to give you something in return for your good deeds. What would you like?";
        angelSays[1] = "After finding diary, angel says]: You want to return home? I’ll take you there.";
    }
    // Update is called once per frame
    void Update()
    {
        
    }

    private void Says(string[] s)
    {
        j++;
        inputText = s[j];
        if (!done && angelSays.Length > j)
        {
            displayText.text = Typewrite(inputText);
        }
    }

    private string Typewrite(string text)
    {
        i++;
        char[] characters = text.ToCharArray();
        outputString = outputString + characters[i].ToString();
        if (i == characters.Length - 1)
        {
            done = true;
        }
        return outputString;
    }
}
